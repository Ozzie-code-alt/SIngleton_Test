﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Singleton_Test
{

    public sealed class Singleton
    {



        private static int counter = 0; // the variable with a private static status 
        private static Singleton instance = null;

        public static Singleton GetInstance
        {
            get
            {
                if (instance == null)
                    instance = new Singleton();
                return instance;
            }
        }
        private Singleton()
        {
            counter++;
            Console.WriteLine("Counter value" + counter.ToString()); // basicalyy im a selfish fuck who just wants the the counter exclusive to class
        }

        public void PrintDetail(string message)
        {
            Console.WriteLine(message);  // Purpose is only to use strings (for now) 
        }





    }

}
