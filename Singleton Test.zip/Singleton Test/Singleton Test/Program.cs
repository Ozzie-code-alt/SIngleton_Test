﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Singleton_Test
{
    public static class Timer
    {


        public static void Main()
        {

            Console.WriteLine("Set timer in Mili seconds :> : ");
            int dueTime = Convert.ToInt32(Console.ReadLine());

            System.Threading.Timer t = new System.Threading.Timer(Callback, null, dueTime, 1000); // in seconds,  i had to call the namespace because the class name is also timer

            Singleton Enter = Singleton.GetInstance;
            Enter.PrintDetail(" Press Enter to Stop");
            Console.ReadLine(); // for pure steroids try 1ms

        }

        private static void Callback(Object parameterLOL) // this will be called by timer, parameter is just there for it to work
        {
            Singleton Task = Singleton.GetInstance;
            Task.PrintDetail("DO UR FUCKIN TASK: " + DateTime.Now); // get time now 

            Singleton deadline = Singleton.GetInstance;
            deadline.PrintDetail("Deadline SUNDAY:"); // This shit to get me do things done



            string message = ("DO UR TASK");
            string title = (" TASK TASK TASK TASK TASK");

            MessageBoxButtons buttons = MessageBoxButtons.AbortRetryIgnore;
            DialogResult result = MessageBox.Show(message, title, buttons, MessageBoxIcon.Warning);

        }
    }
}
